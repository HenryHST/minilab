<div component="dropdown"
     class="dropdown-container"
     id="export-menu">

    <button refs="dropdown@toggle"
         class="icon-list-item text-link"
         aria-haspopup="true"
         aria-expanded="false"
         aria-label="{{ trans('entities.export') }}"
         data-shortcut="export">
        <span>@icon('export')</span>
        <span>{{ trans('entities.export') }}</span>
    </button>

    <ul refs="dropdown@menu" class="wide dropdown-menu" role="menu">
        <li><a href="{{ $entity->getUrl('/export/html') }}" target="_blank" role="menuitem" class="label-item"><span>{{ trans('entities.export_html') }}</span><span>.html</span></a></li>
        <li><a href="{{ $entity->getUrl('/export/pdf') }}" target="_blank" role="menuitem" class="label-item"><span>{{ trans('entities.export_pdf') }}</span><span>.pdf</span></a></li>
        <li><a href="{{ $entity->getUrl('/export/plaintext') }}" target="_blank" role="menuitem" class="label-item"><span>{{ trans('entities.export_text') }}</span><span>.txt</span></a></li>
        <li><a href="{{ $entity->getUrl('/export/markdown') }}" target="_blank" role="menuitem" class="label-item"><span>{{ trans('entities.export_md') }}</span><span>.md</span></a></li>
        <li><a href="{{ $entity->getUrl('/export/zip') }}" target="_blank" role="menuitem" class="label-item"><span>{{ trans('entities.export_zip') }}</span><span>.zip</span></a></li>
        <li><a href="{{ $entity->getUrl('/export/offline-zip') }}" target="_blank" role="menuitem" class="label-item"><span>Offline Web ZIP</span><span>.zip</span></a></li>
    </ul>

</div>
